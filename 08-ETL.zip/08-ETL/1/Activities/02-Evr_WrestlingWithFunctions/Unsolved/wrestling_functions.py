import os
import csv

# Path to collect data from the Resources folder
csv_file = "../Resources/WWE-Data-2016.csv"
# Define the function and have it accept the 'wrestlerData' as its sole parameter
def pct_wrestler(row):
    
    # Find the total number of matches wrestled
    total_number = int(row[1]) + int(row[2]) + int(row[3]) 
    # Find the percentage of matches won
    won_pct = int(row[1]) / total_number * 100

    # Find the percentage of matches lost
    lost_pct = int(row[2]) / total_number * 100
    
    # Find the percentage of matches drawn
    drawn_pct = int(row[3]) / total_number * 100
    
    # Print out the wrestler's name and their percentage stats
    print(f'''
    Wrestler: {row[0]}
    Won: {row[1]} ({won_pct}%)
    Lost: {row[2]} ({lost_pct}%)
    Draw: {row[3]} ({drawn_pct}%)
    ''')

# Read in the CSV file
with open(csv_file, 'r') as csvfile:

    # Split the data on commas
    csvreader = csv.reader(csvfile, delimiter=',')

    # Prompt the user for what wrestler they would like to search for
    name_to_check = input("What wrestler do you want to look for? ")

    # Loop through the data
    for row in csvreader:

        # If the wrestler's name in a row is equal to that which the user input, run the 'print_percentages()' function
        if(name_to_check == row[0]):
            pct_wrestler(row)
