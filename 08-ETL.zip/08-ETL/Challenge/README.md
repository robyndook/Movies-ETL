# Module 8 | Assignment - Extract, Transform, and Load (ETL)

Perform ETL on several movie datasets to predict popular films for a streaming service.
